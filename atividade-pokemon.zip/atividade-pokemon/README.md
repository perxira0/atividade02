# Atividade Prática – Consumo de API e manipulação do DOM (PokéAPI)

## Arquivos
- `index.html` – estrutura do card
- `style.css` – estilo do card (imagem em destaque, ID, altura e peso)
- `script.js` – fetch fornecido pelo professor + manipulação do DOM

## Como executar
Abra `index.html` no navegador (precisa de internet).
Para outro Pokémon, troque `pikachu` na URL do `fetch()` em `script.js`
(ex.: charmander, bulbasaur, squirtle, ditto).
