// Atividade Prática – Consumo de API e manipulação do DOM (PokéAPI)

// Seleção dos elementos da página com document.querySelector()
const elNome = document.querySelector("#nome");
const elId = document.querySelector("#id");
const elAltura = document.querySelector("#altura");
const elPeso = document.querySelector("#peso");
const elImagem = document.querySelector("#imagem");

// Código de consumo da API fornecido pelo professor
fetch("https://pokeapi.co/api/v2/pokemon/pikachu")
  .then(resposta => resposta.json())
  .then(dados => {

    console.log(dados);

    // 1. Inserir o nome do Pokémon
    elNome.textContent = dados.name;

    // 2. Inserir o ID
    elId.textContent = "ID: " + dados.id;

    // 3. Inserir a altura (a API retorna em decímetros)
    elAltura.textContent = dados.height;

    // 4. Inserir o peso (a API retorna em hectogramas)
    elPeso.textContent = dados.weight;

    // 5. Inserir a imagem do Pokémon (arte oficial)
    elImagem.src = dados.sprites.other["official-artwork"].front_default;
    elImagem.alt = "Imagem de " + dados.name;

  })
  .catch(erro => {
    console.log("Erro ao consultar Pokémon:", erro);
    elNome.textContent = "Erro ao carregar";
  });
